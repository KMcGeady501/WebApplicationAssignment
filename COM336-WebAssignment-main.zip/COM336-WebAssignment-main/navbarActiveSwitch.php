<?php
$Highlight_Navbar_Active1 = "deactive";
$Highlight_Navbar_Active2 = "deactive";
$Highlight_Navbar_Active3 = "deactive";
$Highlight_Navbar_Active4 = "deactive";
$Highlight_Navbar_Active5 = "deactive";
$Highlight_Navbar_Active6 = "deactive";
$Highlight_Navbar_Active7 = "deactive";
$Highlight_Navbar_Active8 = "deactive";

switch ($Page_Title_Name) {
case "Ford Dealership":
$Highlight_Navbar_Active1 = "active";

break;
case "FAQs":
$Highlight_Navbar_Active2 = "active";
break;
case "About":
$Highlight_Navbar_Active3 = "active";
break;
case "Contact Us":
$Highlight_Navbar_Active4 = "active";
break;
case "Register":
$Highlight_Navbar_Active5 = "active";
break;
case "Login":
$Highlight_Navbar_Active6 = "active";
break;
case "Shopping":
$Highlight_Navbar_Active7 = "active";
break;
case "Checkout":
$Highlight_Navbar_Active8 = "active";
break;
case "salesInvoice":
$Highlight_Navbar_Active9 = "active";
break; 
default:
$Highlight_Navbar_Active1 = "deactive";
$Highlight_Navbar_Active2 = "deactive";
$Highlight_Navbar_Active3 = "deactive";
$Highlight_Navbar_Active4 = "deactive";
$Highlight_Navbar_Active5 = "deactive";
$Highlight_Navbar_Active6 = "deactive";
$Highlight_Navbar_Active7 = "deactive";
$Highlight_Navbar_Active8 = "deactive";
$Highlight_Navbar_Active9 = "deactive";
}
?>