<!--<div class="wrapper">
    <div class="logo">
        <img src="../webpage/assets/images/fordLogo.jpg" alt="logo">
    </div>-->
    <footer  >
        <div class="footerWrap">
            <p class="company-name">&copy; Ford</p>
            <p class="company-address">Highfield Rd, Craigavon BT64 1AG</p>
            <p class="company-phone">123 456 7890</p>
            <p class="company-email">info@ford.com</p>
            <a href="index.php">Home</a>
            <a href="faq.php">FAQs</a>
            <a href="aboutUs.php">About Us</a>
            <a href="contact.php">Contact Us</a>
            <a href="registerLogin.php">Register/Log In</a>
            <a href="carorder.php">Order</a>
        </div>
    </footer>
<!-- /div> -->  