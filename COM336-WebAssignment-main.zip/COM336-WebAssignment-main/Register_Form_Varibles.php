<?php
$email = '' ;
$password = '';
$Customer_FName = '';
$Customer_LName = '';
$Customer_SEX = '';
$Customer_DOB = '';
$Customer_Contact_Num = '';
$Customer_Address = '';
$Customer_Postcode = '';
?>